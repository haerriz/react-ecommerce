import '../Styles/footer.css';

const Footer =()=>{
    let hello ="new ivin";
    return (
        <>
            <p className="footerNew">This is a Footer</p>
        </>
    )
}
export default Footer;
