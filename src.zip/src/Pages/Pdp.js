import {useState, useEffect} from "react";

const Pdp = () => {

    return (
        <>
            <p className="plp-page">This is a PDP page</p>
        </>
    )
}

export default Pdp;