import {useState, useEffect} from "react";

const Plp = () => {
    const ProductWrapper = {
        border: "1px solid #ddd",
        borderRadius: 5,
        padding: "10px",
        display: "inline-block",
    }
    const ProductImage = {
        display: "block",
        width: "100%",
    }

    const AddToCartMessage = {
        display: "block",
        position: "absolute",
        background: "#adadade0",
        top: "50px",
        width: "100%",
        left: '0',
        padding: '10px',

    }

    const [quantity, setQuantity] = useState(1); // Default quantity is 1
    const [message, setMessage] = useState('');  // State to hold the message for add to cart

    function increment() {
        setQuantity(prevQuantity => prevQuantity + 1);
    }

    function decrement() {
        if (quantity > 1) {
            setQuantity(prevQuantity => prevQuantity - 1);
        }
    }

    function addToCart() {
        setMessage('Item added to cart');
        setTimeout(() => {
            setMessage(''); // Clear the message after 5 seconds
        }, 5000);
    }

    return (
        <>
            <p className="plp-page">This is a PLP page</p>
            <div style={ProductWrapper}>
                <img style={ProductImage} src="https://dummyimage.com/300x300/000/fff" alt="Product"/>
                <a href="product-name">Product Name</a>
                <div>
                    <span>Quantity:
                        <button onClick={decrement}>-</button>
                        <span>{quantity}</span>
                        <button onClick={increment}>+</button>
                    </span>
                    <button onClick={addToCart}>Add to cart</button>
                    {message && <div style={AddToCartMessage}>{message}</div>}
                </div>
            </div>
        </>
    )
}

export default Plp;