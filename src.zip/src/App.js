import { useLocation, Routes, Route } from "react-router-dom";
import logo from './logo.svg';
import './App.css';
import Ivinteach from "./Ivin";
import Header from "./Navigation/Header";
import Footer from "./Navigation/Footer";
import Category from "./Main/Category";
import TopSellers from "./Main/TopSellers";
import Plp from './Pages/Plp';
import Login from './Authentication/Login';
import SignUp from "./Authentication/SignUp";
import Weather from "./Other/Weather";
import {Home} from "./Main/Home";
import HeroBanner from "./Main/HeroBanner";
import Pdp from "./Pages/Pdp";
import MyAdmin from "./Admin/MyAdmin";

const ranText = ['What','New','Nope'];
function GenRandom(max) {
    return Math.floor(Math.random() * (max + 1));
}

function App() {
    const Location = useLocation();
    return (
        <div className="App">
            <Header/>
            <Category/>
            <Routes>
                <Route path="/Home" element={<Home/>}/>
                <Route path="/plp" element={<Plp/>}/>
                <Route path="/plp/pdp" element={<Pdp/>}/>
                <Route path="/Login" element={<Login/>}/>
                <Route path="/Sign-up" element={<SignUp/>}/>
                <Route path="/Sign-up" element={<SignUp/>}/>
                <Route path="/admin/index" element={<MyAdmin/>}/>
            </Routes>
            <Weather/>

            <header className="App-header">
                <img src={logo} className="App-logo" alt="logo"/>
                <p>
                    Edit <code>src/App.js</code> and save to reload.
                </p>
                <a
                    className="App-link"
                    href="https://reactjs.org"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Learn React
                </a>
            </header>
            <MyButton/>
            <Footer/>
        </div>
    );
}

function MyButton() {
    return (
        <button>
            I'm a button
        </button>
    );
}

// export default App;
export default function MyApp() { // only export one function
    return (
        <div>
            <App/>
            <p className="avatar">Test avatar</p>
            <h1>Welcome to my app</h1>
            <MyButton />
            <Ivinteach />
        </div>
    ); // return alone one format
}

// in above export both export and functions called same from 33 to 40
// Arrow => idhuva??? es 6 speciality