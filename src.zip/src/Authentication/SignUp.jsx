import './css/Authentication.css'
const SignUp = () => {
    let hello = "new ivin";
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <div className="col-12">
                            <div className="card">
                                <div className="card-body">
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            <div className="input-group">
                                                <label htmlFor="email">Email</label>
                                                <input type="email" className="form-control" id="email"
                                                       placeholder="Email"/>
                                            </div>
                                            <div className="input-group">
                                                <label htmlFor="password">Password</label>
                                                <input type="password" className="form-control" id="password"
                                                       placeholder="Password"/>
                                            </div>
                                            <div className="input-group">
                                                <label htmlFor="confirmpassword">Confirm password</label>
                                                <input type="password" className="form-control" id="confirmpassword"
                                                       placeholder="Confirm password"/>
                                            </div>
                                            <div className="input-group">
                                                <button type="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default SignUp;