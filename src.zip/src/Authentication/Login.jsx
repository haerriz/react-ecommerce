import React, { useState } from 'react';

const Login = () => {
    const [inputs, setInputs] = useState({
        username: '',
        password: ''
    });
    const [errors, setErrors] = useState({});

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setInputs(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const validateForm = () => {
        let isValid = true;
        const newErrors = {};

        if (!inputs.username) {
            isValid = false;
            newErrors.username = 'Username is required';
        }

        if (!inputs.password) {
            isValid = false;
            newErrors.password = 'Password is required';
        } else if (inputs.password.length < 6) {
            isValid = false;
            newErrors.password = 'Password must be at least 6 characters long';
        }

        setErrors(newErrors);
        return isValid;
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (validateForm()) {
            console.log('Form is valid');
            // You can handle API call or any actions upon valid form here
        } else {
            console.log('Form is invalid');
        }
    };

    return (
        <>
            <div>
                <p>This is a Login Form</p>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <div className="input-group">
                            <label>Username:</label>
                            <input
                                type="text"
                                name="username"
                                placeholder="Your username here!"
                                value={inputs.username}
                                onChange={handleInputChange}
                            />
                            {errors.username && <p style={{ color: 'red' }}>{errors.username}</p>}
                        </div>
                        <div className="input-group">
                            <label>Password:</label>
                            <input
                                type="password"
                                name="password"
                                placeholder="Your password here!"
                                value={inputs.password}
                                onChange={handleInputChange}
                            />
                            {errors.password && <p style={{ color: 'red' }}>{errors.password}</p>}
                        </div>
                        <div className="input-group">
                            <button type="submit">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </>
    );
};

export default Login;
