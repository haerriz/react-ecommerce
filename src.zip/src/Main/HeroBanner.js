const HeroBanner =()=>{
    let hello ="new ivin";
    return (
        <>
            <p>This is a Hero Banner</p>
        </>
    )
}
export default HeroBanner;
