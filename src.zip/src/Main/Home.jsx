import HeroBanner from "./HeroBanner";
import TopSellers from "./TopSellers";

export function Home() {
    return (
        <>
            <p>
                This is home page
            </p>
            <HeroBanner/>
            <TopSellers/>
        </>
    )
}