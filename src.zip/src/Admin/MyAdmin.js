import Header from "../Navigation/Header";
import Footer from "../Navigation/Footer";
import Weather from "../Other/Weather";
import {useLocation} from "react-router-dom";

const MyAdmin = () => {
    const location = useLocation();

    return (
        <div>
            {location.pathname !== "/admin/index" && (
                <>
                    <Header />
                    <Footer />
                    <Weather />
                </>
            )}
            <p className="plp-page">This is an Admin page</p>
        </div>
    );
}

export default MyAdmin;